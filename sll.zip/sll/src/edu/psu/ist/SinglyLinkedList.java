package edu.psu.ist;

import java.util.LinkedList;
import java.util.Queue;

public class SinglyLinkedList<T extends Comparable<T>> {
    Node<T> head;

    public SinglyLinkedList() {
        this.head = null;
    }

    /**
     * Push a new node to the start of the list and replace the head
     * @param data the thing to push on
     * @return the thing that was pushed on
     */

    public Node<T> push(T data) {
        // create the node to push
        Node<T> toPush = new Node<>(data);

        // return the node that we pushed
        Node<T> oldHead = this.head;

        // point the head to the toPush node
        this.head = toPush;

        // point the new head to the temp variable
        this.head.next = oldHead;

        // return the node that we pushed
        return toPush;
    }

    public Node<T> pop() {
        // grab a reference to the head
        Node<T> oldHead = this.head;

        // move the head
        if (this.head != null) {
            this.head = this.head.next;
        }

        // return the head
        return oldHead;
    }

    Node<T> front;
    Node<T> rear;
    int length;

    public void enQueue (T data) {
        if (front == null) {
            rear = new Node<T> (data);
            front = rear;
        } else {
            rear.next = new Node<T>(data);
            rear= rear.next;
        }
        length++;
    }

    public T deQueue(){
        if(front != null) {
            T result = front.data;
            front = front.next;
            length--;
            return result;
        }
        return null;
    }


    /**
     * Appends a node with the data given to it
     *
     * @param data which is what you want to append
     * @return the node that was appended
     */

    public Node<T> append(T data) {
        // create the node to insert
        Node<T> toAppend = new Node<>(data);

        //check if the list is empty (head is null)
        if (this.head == null) {
            // if the list is empty, just assign the head
            this.head = toAppend;
            // return the head
            return this.head;
        }

        // find the last node
        Node lastNode = this.head;
        while (lastNode.next != null) {
            lastNode = lastNode.next;
        }
        // assign the next to the new node
        lastNode.next = toAppend;

        return toAppend;
    }

    public Node<T> delete(T data) {
        // get a pointer to the head
        Node<T> toDelete = null;

        // check if we are deleting the head
        if (this.head.data.compareTo(data) == 0) {
            // if it is, we need to set the head to the next thing
            toDelete = this.head;
            this.head = this.head.next;

            // return deleted code
            return toDelete;
        }


        // get a current pointer
        Node<T> current = this.head;

        // find where to delete
        while (current.next != null) {
            if (current.next.data.compareTo(data) == 0) {
                // cut the code out
                toDelete = current.next;

                // cut the code
                current.next = toDelete.next;
                toDelete.next = null;
                return toDelete;
            }

            // advance if we didn't find it
            current = current.next;
        }


        // return deleted code
        return toDelete;
    }

    /**
     * print out a sll, like this "1 -> 2 -> 3 -> NULL
     *
     * @return the string representation of the sll
     */

    @Override
    public String toString() {
        // get a current pointer
        Node<T> toPrint = this.head;

        // get a string builder
        StringBuilder stringBuilder = new StringBuilder();

        // loop through all the nodes
        while (toPrint != null) {

            // append the content of the string to the builder
            stringBuilder.append(toPrint.data);
            stringBuilder.append(" -> ");

            // advance the pointer
            toPrint = toPrint.next;
        }

        // append null
        stringBuilder.append("NULL");

        // return the result
        return stringBuilder.toString();
    }
}
