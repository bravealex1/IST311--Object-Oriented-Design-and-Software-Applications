package edu.psu.ist;

import org.junit.jupiter.api.Test;

import java.util.Queue;

import static org.junit.jupiter.api.Assertions.*;

class SinglyLinkedListTest {

    @Test
    public void testConstructor() {
        SinglyLinkedList<Integer> sll = new SinglyLinkedList<>();
        assertNull(sll.head);
    }

    @Test
    public void testPush() {
        SinglyLinkedList<Integer> sll = new SinglyLinkedList<>();
        assertNull(sll.head);
        sll.push(1);
        assertEquals(1, sll.head.data);

        sll.push(2);
        assertEquals(2, sll.head.data);

        sll.push(3);
        assertEquals(3, sll.head.data);
    }

    @Test
    public void testPop() {
        SinglyLinkedList<Integer> sll = new SinglyLinkedList<>();
        assertNull(sll.head);
        sll.push(1);
        sll.push(2);
        sll.push(3);
        assertEquals("3 -> 2 -> 1 -> NULL", sll.toString());

        assertEquals(3,sll.pop().data);
        assertEquals(2, sll.pop().data);
        assertEquals(1, sll.pop().data);
    }

    @Test
    public void testEnqueue() {
        SinglyLinkedList<Integer> sll = new SinglyLinkedList<>();
        sll.enQueue(10);
        sll.enQueue(20);
        sll.enQueue(30);
        sll.enQueue(40);
        assertEquals(4, sll.length);
    }

    @Test
    public void testDequeue() {
        SinglyLinkedList<Integer> sll = new SinglyLinkedList<>();
        sll.enQueue(10);
        sll.enQueue(70);
        sll.enQueue(60);
        sll.enQueue(30);
        sll.deQueue();
        assertEquals(3, sll.length);
        assertEquals(70, sll.deQueue());
    }

    @Test
    public void testAppend() {
        SinglyLinkedList<Integer> sll = new SinglyLinkedList<>();
        assertNull(sll.head);
        sll.append(1);
        assertEquals(1, sll.head.data);

        sll.append(2);
        assertEquals(2, sll.head.next.data);

        sll.append(3);
        assertEquals(3, sll.head.next.next.data);
    }

    @Test
    public void testToString() {
        SinglyLinkedList<Integer> sll = new SinglyLinkedList<>();
        assertEquals("NULL", sll.toString());

        sll.append(1);
        assertEquals("1 -> NULL", sll.toString());

        sll.append(2);
        assertEquals("1 -> 2 -> NULL", sll.toString());

        sll.append(3);
        assertEquals("1 -> 2 -> 3 -> NULL", sll.toString());
    }

    @Test
    public void testDelete() {
        SinglyLinkedList<Integer> sll = new SinglyLinkedList<>();
        sll.append(1);
        sll.append(2);
        sll.append(3);
        sll.append(4);

        // deleting something that isn't there
        assertEquals(null, sll.delete(5));
        assertEquals("1 -> 2 -> 3 -> 4 -> NULL", sll.toString());

        // deleting head
        assertEquals(1, sll.delete(1).data);
        assertEquals("2 -> 3 -> 4 -> NULL", sll.toString());

        assertEquals(3, sll.delete(3).data);
        assertEquals("2 -> 4 -> NULL", sll.toString());
    }
}