package edu.psu.ist;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class NodeTest {
    @Test
    public void testConstructor() {
        Node<String> stringNode = new Node<>("data");
        assertEquals("data", stringNode.data);

        Node <Integer> IntegerNode = new Node<>(1);
        assertEquals(1, IntegerNode.data);

        Node<Integer> nextNode = new Node<>(2);
        IntegerNode.next = nextNode;
        assertEquals(1, IntegerNode.next.data);
    }

}