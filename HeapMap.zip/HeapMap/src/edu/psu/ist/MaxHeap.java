package edu.psu.ist;

import java.util.ArrayList;

public class MaxHeap<T extends Comparable<T>> {
    protected ArrayList<T> heap;
    protected int size;

    public MaxHeap() {
        this.heap = new ArrayList<>();
        this.size = 0;
    }

    public void insert(T data) {
        //add the data to the end of the heap
        // TODO change this for the heap sort assignment, hint use the size
        this.heap.add(data);

        //increase the size
        this.size = this.size + 1;

        //heapify up
        this.heapifyUp(this.size - 1);
    }

    protected void heapifyUp(int index) {
//        System.out.println("heapifyUP ran");
//        System.out.println(index);
        // get the parent index
        int parentIndex = (int) Math.floor((index - 1) / 2);
        //System.out.println(parentIndex);

        //is the element to heapify bigger than the parent
        if (this.heap.get(parentIndex).compareTo(this.heap.get(index)) < 0) {
            //System.out.println("I am less than index");
            //System.out.println(this.heap);
            //swap the elements
            T temp = this.heap.get(parentIndex);
            this.heap.set(parentIndex, this.heap.get(index));
            this.heap.set(index, temp);

            //recurse with the new index
            this.heapifyUp(parentIndex);
        }
    }

    public T extract() {
        if (this.size > 0) {
            // get whatever is at the top of the heap
            T temp = this.heap.get(0);

            // swap the end of the heap to the front
            this.heap.set(0, this.heap.get(this.size - 1));
            // remove it from the end (TODO you will need to modify this logic for your sort)
            this.heap.remove(this.size - 1);

//            move the temp to the end of the heap
//            this.heap.set(this.size - 1, temp);

            // decrease the size counter
            this.size = this.size - 1;

            if (this.size > 1) {
                // heapify
                this.heapifyDown(0);
            }
            // return the extracted element
            return temp;
        }
        return null;
    }

    protected void heapifyDown(int index) {
        // get the left and right indices
        int leftIndex = index * 2 + 1;
        int rightIndex = index * 2 + 2;

        // set the max index to the current one at index
        int maxIndex = index;

        // figure out if left child is bigger than the current max
        if (leftIndex < this.size && this.heap.get(leftIndex).compareTo(this.heap.get(maxIndex)) > 0) {
            maxIndex = leftIndex;
        }

        // figure out if the right child is bigger than the current max
        if (rightIndex < this.size && this.heap.get(rightIndex).compareTo(this.heap.get(maxIndex)) > 0) {
            maxIndex = rightIndex;
        }

        // do we need to swap and proceed to heapify
        if (maxIndex != index) {
            // swap
            T temp = this.heap.get(index);
            this.heap.set(index, this.heap.get(maxIndex));
            this.heap.set(maxIndex, temp);

            // recurse if we swapped
            this.heapifyDown(maxIndex);
        }
    }

    /**
     * I think the Big O Analysis of the sort is n*log(n).
     * The Big O Analysis of Heap itself is log(n) because every root always has two children.
     * In addition, in sort, we must loop every element, meaning that we also have to times n.
     * As a result, the big O Analysis for implementing heap sort is n*log(n).
     * @return
     */
    protected ArrayList<T> sort() {
         for (int i = 0; i < heap.size() - 1; i ++) { // O(n)
             swap(heap, size);
             // decrease size by 1
             this.size = this.size - 1; // O(1)
             // heapify down
             this.heapifyDown(0); // big O(log n), because you are splitting elements in the heap
         }
//        }
        return this.heap; // As a result, the big O of sort is O(log n) * O(n), which is n(log n)
    }

    /**
     * swap is Big O of 1 because you are given a specific index
     * @param heap
     * @param index
     */

    protected void swap(ArrayList<T>heap, int index) {
        T temp = this.heap.get(0);
        this.heap.set(0, this.heap.get(index - 1));
        this.heap.set(index - 1, temp);
    }
}
