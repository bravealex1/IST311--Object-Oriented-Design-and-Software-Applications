package edu.psu.ist;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class HeapMapTest {
    @Test
    public void testHeapifyDown() {
        MaxHeap<Integer> maxHeap = new MaxHeap<>();
        maxHeap.heap.add(1);
        maxHeap.heap.add(11);
        maxHeap.heap.add(5);
        maxHeap.heap.add(8);
        maxHeap.heap.add(3);
        maxHeap.heap.add(4);

        maxHeap.size = 6;

        maxHeap.heapifyDown(0);

        assertEquals(11, maxHeap.heap.get(0));
    }

    @Test
    public void testHeapifyUp() {
        //    11
        //  5    8
        // 3 4  15
        MaxHeap<Integer> maxHeap = new MaxHeap<>();
        maxHeap.heap.add(11);
        maxHeap.heap.add(5);
        maxHeap.heap.add(8);
        maxHeap.heap.add(3);
        maxHeap.heap.add(4);
        maxHeap.heap.add(15);
        maxHeap.size = 6;

        maxHeap.heapifyUp(5);

        assertEquals(15, maxHeap.heap.get(0));
        System.out.println(maxHeap.heap);
        //    15
        //  5    11
        //3   4   8
    }

    @Test
    public void testInsert() {
        MaxHeap<Integer> maxHeap = new MaxHeap<>();
        maxHeap.insert(0);
        maxHeap.insert(100);
        maxHeap.insert(40);
        maxHeap.insert(1);
        maxHeap.insert(75);
        maxHeap.insert(50);

        assertEquals("[100, 75, 50, 0, 1, 40]", maxHeap.heap.toString());
    }

    @ Test
    public void testSort() {
        MaxHeap<Integer> maxHeap = new MaxHeap<>();
        maxHeap.insert(0);
        maxHeap.insert(100);
        maxHeap.insert(40);
        maxHeap.insert(1);
        maxHeap.insert(75);
        maxHeap.insert(50);

        maxHeap.size = 6;

        maxHeap.sort();
        assertEquals("[0, 1, 40, 50, 75, 100]", maxHeap.heap.toString());
        System.out.println(maxHeap.heap.toString());
    }

}